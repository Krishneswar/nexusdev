import { Feather, Ionicons } from '@expo/vector-icons';
import { Href, useRouter } from 'expo-router';
import React, { ReactNode } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Room, RoomStatus } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export function IconButton({
  icon,
  onPress,
  accessibilityLabel,
  color,
  size = 20,
}: {
  icon: keyof typeof Feather.glyphMap;
  onPress: () => void;
  accessibilityLabel: string;
  color?: string;
  size?: number;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityLabel={accessibilityLabel}
      testID={`icon-${accessibilityLabel}`}
      onPress={onPress}
      style={({ pressed }) => [styles.iconButton, pressed && styles.pressed]}
    >
      <Feather name={icon} size={size} color={color ?? colors.foreground} />
    </Pressable>
  );
}

export function ScreenHeader({
  eyebrow,
  title,
  action,
  onAction,
}: {
  eyebrow?: string;
  title: string;
  action?: keyof typeof Feather.glyphMap;
  onAction?: () => void;
}) {
  const colors = useColors();
  return (
    <View style={styles.header}>
      <View>
        {eyebrow ? <Text style={[styles.eyebrow, { color: colors.primary }]}>{eyebrow}</Text> : null}
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>{title}</Text>
      </View>
      {action && onAction ? <IconButton icon={action} onPress={onAction} accessibilityLabel={action} /> : null}
    </View>
  );
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return (
    <View style={styles.sectionTitle}>
      <Text style={[styles.sectionHeading, { color: colors.foreground }]}>{title}</Text>
      {action && onAction ? (
        <Pressable onPress={onAction} style={({ pressed }) => pressed && styles.pressed}>
          <Text style={[styles.sectionAction, { color: colors.primary }]}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function StatusPill({ status }: { status: RoomStatus }) {
  const colors = useColors();
  const config = {
    active: { label: 'LIVE', color: colors.accent, icon: 'radio' as const },
    review: { label: 'REVIEW', color: colors.amber, icon: 'git-pull-request' as const },
    idle: { label: 'IDLE', color: colors.mutedForeground, icon: 'pause-circle' as const },
  }[status];
  return (
    <View style={[styles.statusPill, { backgroundColor: `${config.color}18` }]}>
      <Feather name={config.icon} size={11} color={config.color} />
      <Text style={[styles.statusText, { color: config.color }]}>{config.label}</Text>
    </View>
  );
}

export function AvatarStack({ members, limit = 3 }: { members: string[]; limit?: number }) {
  const colors = useColors();
  return (
    <View style={styles.avatarStack}>
      {members.slice(0, limit).map((member, index) => (
        <View key={member} style={[styles.avatar, { backgroundColor: [colors.primary, colors.violet, colors.accent][index % 3], borderColor: colors.card }]}>
          <Text style={[styles.avatarText, { color: colors.primaryForeground }]}>{member}</Text>
        </View>
      ))}
      {members.length > limit ? (
        <View style={[styles.avatar, styles.moreAvatar, { backgroundColor: colors.secondary, borderColor: colors.card }]}>
          <Text style={[styles.avatarText, { color: colors.mutedForeground }]}>+{members.length - limit}</Text>
        </View>
      ) : null}
    </View>
  );
}

export function RoomCard({ room, compact = false }: { room: Room; compact?: boolean }) {
  const colors = useColors();
  const router = useRouter();
  return (
    <Pressable
      testID={`room-${room.id}`}
      onPress={() => router.push(`/room/${room.id}` as Href)}
      style={({ pressed }) => [
        styles.roomCard,
        { backgroundColor: colors.card, borderColor: room.status === 'active' ? `${colors.primary}55` : colors.border },
        pressed && styles.pressed,
      ]}
    >
      <View style={styles.roomTopRow}>
        <View style={[styles.repoMark, { backgroundColor: `${colors.primary}16` }]}>
          <Ionicons name="git-branch-outline" size={17} color={colors.primary} />
        </View>
        <View style={styles.roomNameBlock}>
          <Text style={[styles.roomName, { color: colors.foreground }]} numberOfLines={1}>{room.name}</Text>
          <Text style={[styles.roomRepo, { color: colors.mutedForeground }]} numberOfLines={1}>{room.repo}</Text>
        </View>
        <StatusPill status={room.status} />
      </View>
      <View style={[styles.branchRow, { borderTopColor: colors.border }]}>
        <View style={styles.branchInfo}>
          <Feather name="git-branch" size={13} color={colors.mutedForeground} />
          <Text style={[styles.branchText, { color: colors.mutedForeground }]}>{room.branch}</Text>
        </View>
        <Text style={[styles.activityTime, { color: colors.mutedForeground }]}>{room.lastActivity}</Text>
      </View>
      {!compact ? (
        <View style={styles.roomBottomRow}>
          <AvatarStack members={room.members} />
          <View style={styles.healthMini}>
            <Text style={[styles.healthLabel, { color: colors.mutedForeground }]}>HEALTH</Text>
            <Text style={[styles.healthValue, { color: room.health > 80 ? colors.accent : colors.amber }]}>{room.health}</Text>
          </View>
        </View>
      ) : null}
    </Pressable>
  );
}

export function MetricBar({ label, value, color }: { label: string; value: number; color?: string }) {
  const colors = useColors();
  const fillColor = color ?? colors.primary;
  return (
    <View style={styles.metricBar}>
      <View style={styles.metricLabelRow}>
        <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <Text style={[styles.metricValue, { color: fillColor }]}>{value}%</Text>
      </View>
      <View style={[styles.track, { backgroundColor: colors.secondary }]}>
        <View style={[styles.fill, { width: `${value}%`, backgroundColor: fillColor }]} />
      </View>
    </View>
  );
}

export function Surface({ children, style }: { children: ReactNode; style?: object }) {
  const colors = useColors();
  return <View style={[styles.surface, { backgroundColor: colors.card, borderColor: colors.border }, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 22 },
  eyebrow: { fontSize: 11, fontFamily: 'Inter_700Bold', letterSpacing: 1.5, marginBottom: 6 },
  headerTitle: { fontSize: 30, fontFamily: 'Inter_700Bold', letterSpacing: -0.8 },
  iconButton: { width: 42, height: 42, alignItems: 'center', justifyContent: 'center', borderRadius: 21 },
  pressed: { opacity: 0.65, transform: [{ scale: 0.98 }] },
  sectionTitle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  sectionHeading: { fontSize: 16, fontFamily: 'Inter_700Bold', letterSpacing: -0.2 },
  sectionAction: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  surface: { borderWidth: 1, borderRadius: 18, padding: 16 },
  roomCard: { borderWidth: 1, borderRadius: 18, padding: 16, marginBottom: 12 },
  roomTopRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  repoMark: { width: 36, height: 36, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  roomNameBlock: { flex: 1 },
  roomName: { fontSize: 15, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  roomRepo: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  statusPill: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 10 },
  statusText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.7 },
  branchRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderTopWidth: 1, marginTop: 15, paddingTop: 12 },
  branchInfo: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  branchText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  activityTime: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  roomBottomRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 },
  avatarStack: { flexDirection: 'row', alignItems: 'center' },
  avatar: { width: 27, height: 27, borderRadius: 14, borderWidth: 2, alignItems: 'center', justifyContent: 'center', marginRight: -5 },
  moreAvatar: { marginLeft: 3 },
  avatarText: { fontSize: 9, fontFamily: 'Inter_700Bold' },
  healthMini: { flexDirection: 'row', alignItems: 'baseline', gap: 7 },
  healthLabel: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.7 },
  healthValue: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  metricBar: { marginTop: 14 },
  metricLabelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 7 },
  metricLabel: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  metricValue: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  track: { height: 7, borderRadius: 4, overflow: 'hidden' },
  fill: { height: '100%', borderRadius: 4 },
});
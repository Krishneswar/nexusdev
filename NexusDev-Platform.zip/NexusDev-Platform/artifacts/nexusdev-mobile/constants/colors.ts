/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    text: '#F4F7FB',
    tint: '#55B7FF',
    background: '#08111F',
    foreground: '#F4F7FB',
    card: '#101D2F',
    cardForeground: '#F4F7FB',
    primary: '#55B7FF',
    primaryForeground: '#07111F',
    secondary: '#172941',
    secondaryForeground: '#DCEBFA',
    muted: '#122239',
    mutedForeground: '#86A0BA',
    accent: '#22D3A7',
    accentForeground: '#061A19',
    destructive: '#FF647C',
    destructiveForeground: '#260913',
    border: '#203651',
    input: '#14263D',
    violet: '#A78BFA',
    amber: '#FFB86B',
    cyan: '#6FE7FF',
    terminal: '#07101C',
  },
  dark: {
    text: '#F4F7FB',
    tint: '#55B7FF',
    background: '#08111F',
    foreground: '#F4F7FB',
    card: '#101D2F',
    cardForeground: '#F4F7FB',
    primary: '#55B7FF',
    primaryForeground: '#07111F',
    secondary: '#172941',
    secondaryForeground: '#DCEBFA',
    muted: '#122239',
    mutedForeground: '#86A0BA',
    accent: '#22D3A7',
    accentForeground: '#061A19',
    destructive: '#FF647C',
    destructiveForeground: '#260913',
    border: '#203651',
    input: '#14263D',
    violet: '#A78BFA',
    amber: '#FFB86B',
    cyan: '#6FE7FF',
    terminal: '#07101C',
  },
  radius: 16,
};

export default colors;

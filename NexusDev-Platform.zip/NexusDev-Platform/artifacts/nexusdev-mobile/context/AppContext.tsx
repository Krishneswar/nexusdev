import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';

export type RoomStatus = 'active' | 'review' | 'idle';
export type Room = {
  id: string;
  name: string;
  repo: string;
  branch: string;
  status: RoomStatus;
  members: string[];
  health: number;
  lastActivity: string;
  files: string[];
};

export type Activity = {
  id: string;
  title: string;
  detail: string;
  time: string;
  kind: 'commit' | 'ai' | 'member' | 'terminal';
};

const seedRooms: Room[] = [
  {
    id: 'orbit-api',
    name: 'orbit-api',
    repo: 'github.com/knights/orbit-api',
    branch: 'fix/auth-refresh',
    status: 'active',
    members: ['KG', 'JB', 'AM'],
    health: 86,
    lastActivity: '2 min ago',
    files: ['src/auth/refresh.ts', 'src/middleware/session.ts', 'tests/auth.spec.ts', 'package.json'],
  },
  {
    id: 'atlas-web',
    name: 'atlas-web',
    repo: 'github.com/knights/atlas-web',
    branch: 'main',
    status: 'review',
    members: ['KG', 'LS'],
    health: 72,
    lastActivity: '34 min ago',
    files: ['app/routes.tsx', 'components/CommandMenu.tsx', 'lib/analytics.ts'],
  },
  {
    id: 'signal-worker',
    name: 'signal-worker',
    repo: 'github.com/knights/signal-worker',
    branch: 'feat/retry-policy',
    status: 'idle',
    members: ['JB'],
    health: 94,
    lastActivity: 'Yesterday',
    files: ['src/worker.ts', 'src/retry.ts', 'README.md'],
  },
];

const seedActivity: Activity[] = [
  { id: '1', title: 'AI flagged a risky branch', detail: 'refresh.ts · token expiry path', time: '2m', kind: 'ai' },
  { id: '2', title: 'Jeevan joined the room', detail: 'orbit-api · fix/auth-refresh', time: '8m', kind: 'member' },
  { id: '3', title: 'Terminal run completed', detail: 'npm test · 18 passed', time: '14m', kind: 'terminal' },
  { id: '4', title: 'Commit pushed', detail: 'a84f1d · tighten refresh guard', time: '27m', kind: 'commit' },
];

type AppContextValue = {
  rooms: Room[];
  activity: Activity[];
  createRoom: (name: string, repo: string) => void;
  toggleRoomStatus: (id: string) => void;
  isReady: boolean;
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [rooms, setRooms] = useState<Room[]>(seedRooms);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem('nexusdev-rooms')
      .then((stored) => {
        if (stored) setRooms(JSON.parse(stored) as Room[]);
      })
      .catch(() => undefined)
      .finally(() => setIsReady(true));
  }, []);

  useEffect(() => {
    if (isReady) AsyncStorage.setItem('nexusdev-rooms', JSON.stringify(rooms)).catch(() => undefined);
  }, [rooms, isReady]);

  const value = useMemo(
    () => ({
      rooms,
      activity: seedActivity,
      isReady,
      createRoom: (name: string, repo: string) => {
        const id = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-');
        if (!id) return;
        setRooms((current) => [
          {
            id,
            name: name.trim(),
            repo: repo.trim() || 'github.com/your-team/new-room',
            branch: 'main',
            status: 'active',
            members: ['KG'],
            health: 100,
            lastActivity: 'Just now',
            files: ['README.md', 'src/index.ts', 'package.json'],
          },
          ...current,
        ]);
      },
      toggleRoomStatus: (id: string) => {
        setRooms((current) =>
          current.map((room) => ({
            ...room,
            status: room.id === id ? (room.status === 'active' ? 'idle' : 'active') : room.status,
          })),
        );
      },
    }),
    [isReady, rooms],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside AppProvider');
  return context;
}
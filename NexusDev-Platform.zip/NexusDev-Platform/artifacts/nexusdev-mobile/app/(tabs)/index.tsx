import { Feather, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Activity, useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';
import { AvatarStack, RoomCard, SectionTitle, Surface } from '@/components/NexusUI';

function ActivityRow({ item }: { item: Activity }) {
  const colors = useColors();
  const icon = { ai: 'zap', member: 'user-plus', terminal: 'terminal', commit: 'git-commit' }[item.kind] as keyof typeof Feather.glyphMap;
  const iconColor = { ai: colors.violet, member: colors.accent, terminal: colors.cyan, commit: colors.primary }[item.kind];
  return (
    <View style={styles.activityRow}>
      <View style={[styles.activityIcon, { backgroundColor: `${iconColor}18` }]}>
        <Feather name={icon} size={16} color={iconColor} />
      </View>
      <View style={styles.activityCopy}>
        <Text style={[styles.activityTitle, { color: colors.foreground }]}>{item.title}</Text>
        <Text style={[styles.activityDetail, { color: colors.mutedForeground }]}>{item.detail}</Text>
      </View>
      <Text style={[styles.activityTime, { color: colors.mutedForeground }]}>{item.time}</Text>
    </View>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { rooms, activity } = useApp();
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const activeRoom = rooms.find((room) => room.status === 'active') ?? rooms[0];

  const goToAi = () => {
    Haptics.selectionAsync();
    router.push('/ai');
  };

  return (
    <ScrollView
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: topInset + 18, paddingBottom: insets.bottom + 110 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.topline}>
        <View>
          <Text style={[styles.greeting, { color: colors.mutedForeground }]}>FRIDAY, SEP 25</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Good morning, <Text style={{ color: colors.primary }}>Krishneswar</Text></Text>
        </View>
        <Pressable testID="profile-avatar" onPress={() => router.push('/(tabs)/profile')} style={({ pressed }) => [styles.profileAvatar, { backgroundColor: colors.primary }, pressed && styles.pressed]}>
          <Text style={[styles.profileInitials, { color: colors.primaryForeground }]}>KG</Text>
          <View style={[styles.onlineDot, { backgroundColor: colors.accent, borderColor: colors.background }]} />
        </Pressable>
      </View>

      <Surface style={styles.statusBanner}>
        <View style={[styles.liveDot, { backgroundColor: colors.accent }]} />
        <View style={styles.statusCopy}>
          <Text style={[styles.statusTitle, { color: colors.foreground }]}>All systems online</Text>
          <Text style={[styles.statusDetail, { color: colors.mutedForeground }]}>3 rooms synced · 1 active session</Text>
        </View>
        <Ionicons name="pulse-outline" size={22} color={colors.accent} />
      </Surface>

      <SectionTitle title="Live room" action="Open rooms" onAction={() => router.push('/(tabs)/rooms')} />
      {activeRoom ? <RoomCard room={activeRoom} /> : null}

      <SectionTitle title="Quick actions" />
      <View style={styles.actionGrid}>
        <Pressable testID="ask-ai-action" onPress={goToAi} style={({ pressed }) => [styles.actionCard, { backgroundColor: `${colors.violet}15`, borderColor: `${colors.violet}35` }, pressed && styles.pressed]}>
          <View style={[styles.actionIcon, { backgroundColor: `${colors.violet}25` }]}><Feather name="message-square" size={18} color={colors.violet} /></View>
          <Text style={[styles.actionTitle, { color: colors.foreground }]}>Ask AI</Text>
          <Text style={[styles.actionHint, { color: colors.mutedForeground }]}>Debug in context</Text>
        </Pressable>
        <Pressable testID="insights-action" onPress={() => router.push('/(tabs)/insights')} style={({ pressed }) => [styles.actionCard, { backgroundColor: `${colors.accent}12`, borderColor: `${colors.accent}35` }, pressed && styles.pressed]}>
          <View style={[styles.actionIcon, { backgroundColor: `${colors.accent}25` }]}><Feather name="trending-up" size={18} color={colors.accent} /></View>
          <Text style={[styles.actionTitle, { color: colors.foreground }]}>Code health</Text>
          <Text style={[styles.actionHint, { color: colors.mutedForeground }]}>View team pulse</Text>
        </Pressable>
      </View>

      <SectionTitle title="Recent activity" action="View all" onAction={() => router.push('/(tabs)/rooms')} />
      <Surface>
        {activity.map((item) => <ActivityRow key={item.id} item={item} />)}
      </Surface>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  topline: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 },
  greeting: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.4, marginBottom: 7 },
  title: { fontSize: 24, fontFamily: 'Inter_700Bold', letterSpacing: -0.6, maxWidth: 300 },
  profileAvatar: { width: 43, height: 43, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  profileInitials: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  onlineDot: { position: 'absolute', right: -1, bottom: 1, width: 12, height: 12, borderRadius: 6, borderWidth: 2 },
  statusBanner: { flexDirection: 'row', alignItems: 'center', padding: 14, marginBottom: 26 },
  liveDot: { width: 9, height: 9, borderRadius: 5, marginRight: 11 },
  statusCopy: { flex: 1 },
  statusTitle: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  statusDetail: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  actionGrid: { flexDirection: 'row', gap: 10, marginBottom: 26 },
  actionCard: { flex: 1, borderRadius: 17, borderWidth: 1, padding: 14, minHeight: 112 },
  actionIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  actionTitle: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  actionHint: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  activityRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10 },
  activityIcon: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 11 },
  activityCopy: { flex: 1 },
  activityTitle: { fontSize: 12, fontFamily: 'Inter_600SemiBold', marginBottom: 3 },
  activityDetail: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  activityTime: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  pressed: { opacity: 0.68, transform: [{ scale: 0.98 }] },
});

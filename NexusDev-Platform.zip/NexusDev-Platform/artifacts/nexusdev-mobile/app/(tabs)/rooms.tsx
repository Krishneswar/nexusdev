import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import { Keyboard, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoomCard, ScreenHeader } from '@/components/NexusUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function RoomsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { rooms, createRoom } = useApp();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [repo, setRepo] = useState('');
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const handleCreate = () => {
    if (!name.trim()) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    createRoom(name, repo);
    setName('');
    setRepo('');
    setShowCreate(false);
    Keyboard.dismiss();
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={[styles.screen, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: topInset + 18, paddingBottom: insets.bottom + 110 }}
      bottomOffset={32}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
    >
      <ScreenHeader eyebrow="NEXUSDEV / WORKSPACES" title="Your rooms" action="plus" onAction={() => setShowCreate((value) => !value)} />
      <Text style={[styles.subhead, { color: colors.mutedForeground }]}>Live workspaces for pair-debugging, review, and replay.</Text>

      {showCreate ? (
        <View style={[styles.createPanel, { backgroundColor: colors.card, borderColor: colors.primary }]}>
          <View style={styles.createTitleRow}>
            <View style={[styles.createIcon, { backgroundColor: `${colors.primary}18` }]}><Feather name="plus" size={18} color={colors.primary} /></View>
            <View><Text style={[styles.createTitle, { color: colors.foreground }]}>Start a new room</Text><Text style={[styles.createHint, { color: colors.mutedForeground }]}>You can invite teammates after</Text></View>
          </View>
          <TextInput testID="room-name-input" value={name} onChangeText={setName} placeholder="Room name" placeholderTextColor={colors.mutedForeground} style={[styles.input, { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border }]} autoCapitalize="none" />
          <TextInput testID="room-repo-input" value={repo} onChangeText={setRepo} placeholder="Repository URL (optional)" placeholderTextColor={colors.mutedForeground} style={[styles.input, { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border }]} autoCapitalize="none" />
          <Pressable testID="create-room-button" onPress={handleCreate} disabled={!name.trim()} style={({ pressed }) => [styles.createButton, { backgroundColor: name.trim() ? colors.primary : colors.secondary }, pressed && styles.pressed]}>
            <Text style={[styles.createButtonText, { color: name.trim() ? colors.primaryForeground : colors.mutedForeground }]}>Create room</Text>
            <Feather name="arrow-up-right" size={16} color={name.trim() ? colors.primaryForeground : colors.mutedForeground} />
          </Pressable>
        </View>
      ) : null}

      <View style={styles.filterRow}>
        <Text style={[styles.count, { color: colors.mutedForeground }]}>{rooms.length} rooms</Text>
        <View style={[styles.syncTag, { backgroundColor: `${colors.accent}15` }]}><View style={[styles.syncDot, { backgroundColor: colors.accent }]} /><Text style={[styles.syncText, { color: colors.accent }]}>SYNCED</Text></View>
      </View>
      {rooms.map((room) => <RoomCard key={room.id} room={room} />)}
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  subhead: { fontSize: 13, lineHeight: 20, marginTop: -12, marginBottom: 22, maxWidth: 310, fontFamily: 'Inter_400Regular' },
  createPanel: { borderWidth: 1, borderRadius: 18, padding: 15, marginBottom: 22 },
  createTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 15 },
  createIcon: { width: 35, height: 35, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  createTitle: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  createHint: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  input: { height: 45, borderWidth: 1, borderRadius: 11, paddingHorizontal: 12, fontSize: 12, fontFamily: 'Inter_500Medium', marginBottom: 9 },
  createButton: { height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, marginTop: 3 },
  createButtonText: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  filterRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 11 },
  count: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  syncTag: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 8, paddingVertical: 5, borderRadius: 8 },
  syncDot: { width: 5, height: 5, borderRadius: 3 },
  syncText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.8 },
  pressed: { opacity: 0.68 },
});
import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MetricBar, ScreenHeader, SectionTitle, Surface } from '@/components/NexusUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

export default function InsightsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { rooms } = useApp();
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  const average = Math.round(rooms.reduce((sum, room) => sum + room.health, 0) / Math.max(rooms.length, 1));
  return (
    <ScrollView style={[styles.screen, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingTop: topInset + 18, paddingBottom: insets.bottom + 110 }} showsVerticalScrollIndicator={false}>
      <ScreenHeader eyebrow="NEXUSDEV / SIGNALS" title="Team pulse" action="bell" onAction={() => undefined} />
      <Text style={[styles.subhead, { color: colors.mutedForeground }]}>A living view of what your codebase is telling the team.</Text>
      <Surface style={styles.scoreCard}>
        <View style={styles.scoreTop}>
          <View><Text style={[styles.scoreEyebrow, { color: colors.accent }]}>TEAM CODE HEALTH</Text><Text style={[styles.scoreTitle, { color: colors.foreground }]}>Strong momentum</Text></View>
          <View style={[styles.scoreCircle, { borderColor: colors.accent }]}><Text style={[styles.scoreNumber, { color: colors.accent }]}>{average}</Text><Text style={[styles.scoreOutOf, { color: colors.mutedForeground }]}>/100</Text></View>
        </View>
        <Text style={[styles.scoreDetail, { color: colors.mutedForeground }]}>Up 8 points from last week. Your team is resolving risky paths before they reach review.</Text>
        <MetricBar label="Overall stability" value={average} color={colors.accent} />
      </Surface>

      <SectionTitle title="Predictive bug radar" action="Last 7 days" />
      <Surface>
        <View style={styles.radarHeader}><View style={[styles.radarIcon, { backgroundColor: `${colors.violet}18` }]}><Feather name="crosshair" size={18} color={colors.violet} /></View><View style={styles.radarCopy}><Text style={[styles.radarTitle, { color: colors.foreground }]}>2 files need attention</Text><Text style={[styles.radarDetail, { color: colors.mutedForeground }]}>Based on recent commits and failure patterns</Text></View></View>
        <View style={[styles.fileAlert, { borderTopColor: colors.border }]}><View style={[styles.alertDot, { backgroundColor: colors.destructive }]} /><Text style={[styles.fileName, { color: colors.foreground }]}>src/auth/refresh.ts</Text><Text style={[styles.riskText, { color: colors.destructive }]}>82% risk</Text></View>
        <View style={[styles.fileAlert, { borderTopColor: colors.border }]}><View style={[styles.alertDot, { backgroundColor: colors.amber }]} /><Text style={[styles.fileName, { color: colors.foreground }]}>lib/retry-policy.ts</Text><Text style={[styles.riskText, { color: colors.amber }]}>64% risk</Text></View>
      </Surface>

      <SectionTitle title="Room health" />
      {rooms.map((room) => <Surface key={room.id} style={styles.roomHealth}><View style={styles.roomHealthHeader}><Text style={[styles.roomHealthName, { color: colors.foreground }]}>{room.name}</Text><Text style={[styles.roomHealthNumber, { color: room.health > 80 ? colors.accent : colors.amber }]}>{room.health}</Text></View><MetricBar label={room.branch} value={room.health} color={room.health > 80 ? colors.accent : colors.amber} /></Surface>)}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  subhead: { fontSize: 13, lineHeight: 20, marginTop: -12, marginBottom: 22, fontFamily: 'Inter_400Regular' },
  scoreCard: { marginBottom: 25, overflow: 'hidden' },
  scoreTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  scoreEyebrow: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1.2, marginBottom: 8 },
  scoreTitle: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  scoreCircle: { width: 70, height: 70, borderWidth: 3, borderRadius: 35, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' },
  scoreNumber: { fontSize: 22, fontFamily: 'Inter_700Bold' },
  scoreOutOf: { fontSize: 10, fontFamily: 'Inter_500Medium', marginTop: 8 },
  scoreDetail: { fontSize: 11, lineHeight: 17, marginTop: 16, fontFamily: 'Inter_400Regular' },
  radarHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 7 },
  radarIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginRight: 11 },
  radarCopy: { flex: 1 },
  radarTitle: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  radarDetail: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  fileAlert: { flexDirection: 'row', alignItems: 'center', borderTopWidth: 1, paddingTop: 13, marginTop: 10 },
  alertDot: { width: 7, height: 7, borderRadius: 4, marginRight: 9 },
  fileName: { flex: 1, fontSize: 11, fontFamily: 'Inter_500Medium' },
  riskText: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  roomHealth: { marginBottom: 10 },
  roomHealthHeader: { flexDirection: 'row', justifyContent: 'space-between' },
  roomHealthName: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  roomHealthNumber: { fontSize: 14, fontFamily: 'Inter_700Bold' },
});
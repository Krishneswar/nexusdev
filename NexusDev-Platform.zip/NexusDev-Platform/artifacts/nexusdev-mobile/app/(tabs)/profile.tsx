import { Feather } from '@expo/vector-icons';
import React from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ScreenHeader, Surface } from '@/components/NexusUI';
import { useColors } from '@/hooks/useColors';

const settings = [
  { icon: 'github' as const, title: 'GitHub connection', detail: 'knights / connected', colorKey: 'primary' },
  { icon: 'users' as const, title: 'Team members', detail: '3 active collaborators', colorKey: 'violet' },
  { icon: 'shield' as const, title: 'Security & privacy', detail: 'All sessions protected', colorKey: 'accent' },
];

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  return (
    <ScrollView style={[styles.screen, { backgroundColor: colors.background }]} contentContainerStyle={{ paddingTop: topInset + 18, paddingBottom: insets.bottom + 110 }} showsVerticalScrollIndicator={false}>
      <ScreenHeader eyebrow="NEXUSDEV / ACCOUNT" title="Your profile" action="settings" onAction={() => undefined} />
      <Surface style={styles.profileCard}>
        <View style={[styles.largeAvatar, { backgroundColor: colors.primary }]}><Text style={[styles.largeAvatarText, { color: colors.primaryForeground }]}>KG</Text><View style={[styles.bigOnline, { backgroundColor: colors.accent, borderColor: colors.card }]} /></View>
        <View style={styles.profileCopy}><Text style={[styles.profileName, { color: colors.foreground }]}>Krishneswar GR</Text><Text style={[styles.profileHandle, { color: colors.mutedForeground }]}>@krishneswar · Team Knights</Text><View style={[styles.rolePill, { backgroundColor: `${colors.primary}16` }]}><Text style={[styles.roleText, { color: colors.primary }]}>ENGINEER</Text></View></View>
      </Surface>
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>WORKSPACE SETTINGS</Text>
      <Surface style={styles.settingsSurface}>
        {settings.map((item, index) => {
          const color = colors[item.colorKey as 'primary' | 'violet' | 'accent'];
          return <Pressable key={item.title} onPress={() => undefined} style={({ pressed }) => [styles.settingRow, index < settings.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }, pressed && styles.pressed]}>
            <View style={[styles.settingIcon, { backgroundColor: `${color}18` }]}><Feather name={item.icon} size={17} color={color} /></View>
            <View style={styles.settingCopy}><Text style={[styles.settingTitle, { color: colors.foreground }]}>{item.title}</Text><Text style={[styles.settingDetail, { color: colors.mutedForeground }]}>{item.detail}</Text></View>
            <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
          </Pressable>;
        })}
      </Surface>
      <View style={styles.brandLockup}><View style={[styles.brandMark, { backgroundColor: colors.primary }]}><Feather name="code" size={15} color={colors.primaryForeground} /></View><Text style={[styles.brandName, { color: colors.foreground }]}>NEXUSDEV</Text><Text style={[styles.version, { color: colors.mutedForeground }]}>MOBILE 1.0.0</Text></View>
      <Text style={[styles.footer, { color: colors.mutedForeground }]}>Debug together. Ship faster.</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, paddingHorizontal: 18 },
  profileCard: { flexDirection: 'row', alignItems: 'center', marginBottom: 26 },
  largeAvatar: { width: 63, height: 63, borderRadius: 32, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  largeAvatarText: { fontSize: 19, fontFamily: 'Inter_700Bold' },
  bigOnline: { position: 'absolute', width: 16, height: 16, borderRadius: 8, right: -1, bottom: 1, borderWidth: 3 },
  profileCopy: { flex: 1 },
  profileName: { fontSize: 17, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  profileHandle: { fontSize: 11, fontFamily: 'Inter_400Regular', marginBottom: 9 },
  rolePill: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  roleText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.8 },
  sectionLabel: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.2, marginBottom: 10 },
  settingsSurface: { paddingVertical: 0, marginBottom: 34 },
  settingRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14 },
  settingIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginRight: 11 },
  settingCopy: { flex: 1 },
  settingTitle: { fontSize: 12, fontFamily: 'Inter_600SemiBold', marginBottom: 3 },
  settingDetail: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  brandLockup: { alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7 },
  brandMark: { width: 24, height: 24, borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  brandName: { fontSize: 12, fontFamily: 'Inter_700Bold', letterSpacing: 1.4 },
  version: { fontSize: 9, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.7, marginLeft: 3 },
  footer: { textAlign: 'center', fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 11 },
  pressed: { opacity: 0.65 },
});
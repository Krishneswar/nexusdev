import { Feather } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconButton } from '@/components/NexusUI';
import { useColors } from '@/hooks/useColors';

type Message = { id: string; role: 'ai' | 'user'; text: string };

export default function AiScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { room } = useLocalSearchParams<{ room?: string }>();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', role: 'ai', text: room ? `I’m looking at ${room} with you. What should we trace first?` : 'I’m ready to help you debug. Bring me a failing test, a stack trace, or a file you’re unsure about.' },
    { id: '2', role: 'ai', text: 'I already have the active room context and recent terminal run in view.' },
  ]);
  const topInset = Platform.OS === 'web' ? 67 : insets.top;

  const send = () => {
    const text = input.trim();
    if (!text) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setMessages((current) => [...current, { id: `${Date.now()}`, role: 'user', text }]);
    setInput('');
    setTimeout(() => {
      setMessages((current) => [...current, { id: `${Date.now()}-ai`, role: 'ai', text: 'I’d start by making the refresh operation single-flight, then add a concurrency test around the expiry boundary. Want me to sketch that patch?' }]);
    }, 450);
  };

  return (
    <KeyboardAvoidingView style={[styles.screen, { backgroundColor: colors.background }]} behavior="padding" keyboardVerticalOffset={0}>
      <View style={[styles.header, { paddingTop: topInset + 9, borderBottomColor: colors.border }]}>
        <IconButton icon="arrow-left" onPress={() => router.back()} accessibilityLabel="back" />
        <View style={styles.headerCopy}><View style={styles.titleRow}><View style={[styles.aiDot, { backgroundColor: colors.violet }]} /><Text style={[styles.title, { color: colors.foreground }]}>AI Debug Companion</Text></View><Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{room ? `Context: ${room}` : 'Your codebase, in context'}</Text></View>
        <IconButton icon="sliders" onPress={() => undefined} accessibilityLabel="settings" />
      </View>
      <FlatList
        data={[...messages].reverse()}
        inverted
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 18, paddingBottom: 24 }}
        keyboardDismissMode="interactive"
        keyboardShouldPersistTaps="handled"
        renderItem={({ item }) => <View style={[styles.messageRow, item.role === 'user' && styles.userRow]}><View style={[styles.messageBubble, { backgroundColor: item.role === 'user' ? colors.primary : colors.card, borderColor: item.role === 'user' ? colors.primary : colors.border }]}><Text style={[styles.messageText, { color: item.role === 'user' ? colors.primaryForeground : colors.foreground }]}>{item.text}</Text></View></View>}
      />
      <View style={[styles.composerWrap, { paddingBottom: Math.max(insets.bottom, 12), borderTopColor: colors.border, backgroundColor: colors.background }]}>
        <View style={[styles.composer, { backgroundColor: colors.input, borderColor: colors.border }]}><TextInput testID="ai-input" value={input} onChangeText={setInput} onSubmitEditing={send} returnKeyType="send" placeholder="Ask about the bug..." placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground }]} multiline /><Pressable testID="ai-send" onPress={send} disabled={!input.trim()} style={({ pressed }) => [styles.sendButton, { backgroundColor: input.trim() ? colors.primary : colors.secondary }, pressed && styles.pressed]}><Feather name="arrow-up" size={17} color={input.trim() ? colors.primaryForeground : colors.mutedForeground} /></Pressable></View>
        <View style={styles.composerHint}><Feather name="zap" size={11} color={colors.violet} /><Text style={[styles.hintText, { color: colors.mutedForeground }]}>Context-aware suggestions are enabled</Text></View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 11, paddingBottom: 13, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center' },
  headerCopy: { flex: 1, marginHorizontal: 7 },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  aiDot: { width: 8, height: 8, borderRadius: 4 },
  title: { fontSize: 15, fontFamily: 'Inter_700Bold' },
  subtitle: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 4 },
  messageRow: { alignItems: 'flex-start', marginBottom: 12 },
  userRow: { alignItems: 'flex-end' },
  messageBubble: { maxWidth: '86%', borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, paddingVertical: 12 },
  messageText: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_500Medium' },
  composerWrap: { borderTopWidth: 1, paddingHorizontal: 14, paddingTop: 11 },
  composer: { minHeight: 48, borderWidth: 1, borderRadius: 15, flexDirection: 'row', alignItems: 'center', paddingLeft: 13, paddingRight: 6 },
  input: { flex: 1, fontSize: 12, lineHeight: 18, maxHeight: 90, paddingVertical: 10, fontFamily: 'Inter_400Regular' },
  sendButton: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center', marginLeft: 7 },
  composerHint: { flexDirection: 'row', alignItems: 'center', gap: 5, justifyContent: 'center', paddingTop: 8 },
  hintText: { fontSize: 9, fontFamily: 'Inter_400Regular' },
  pressed: { opacity: 0.65 },
});
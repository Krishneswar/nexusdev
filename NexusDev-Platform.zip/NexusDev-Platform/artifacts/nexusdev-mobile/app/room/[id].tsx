import { Feather, Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import { Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AvatarStack, IconButton, MetricBar, StatusPill, Surface } from '@/components/NexusUI';
import { useApp } from '@/context/AppContext';
import { useColors } from '@/hooks/useColors';

type RoomTab = 'overview' | 'files' | 'terminal' | 'chat';

export default function RoomScreen() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { rooms, toggleRoomStatus } = useApp();
  const room = rooms.find((item) => item.id === id) ?? rooms[0];
  const [tab, setTab] = useState<RoomTab>('overview');
  const topInset = Platform.OS === 'web' ? 67 : insets.top;
  if (!room) return null;

  const openAi = () => {
    Haptics.selectionAsync();
    router.push({ pathname: '/ai', params: { room: room.name } });
  };

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10 }]}>
        <IconButton icon="arrow-left" onPress={() => router.back()} accessibilityLabel="back" />
        <View style={styles.headerCopy}><Text style={[styles.headerEyebrow, { color: colors.primary }]}>ROOM</Text><Text style={[styles.headerTitle, { color: colors.foreground }]} numberOfLines={1}>{room.name}</Text></View>
        <IconButton icon="more-horizontal" onPress={() => toggleRoomStatus(room.id)} accessibilityLabel="more" />
      </View>
      <View style={styles.roomMeta}><StatusPill status={room.status} /><View style={styles.metaItem}><Feather name="git-branch" size={12} color={colors.mutedForeground} /><Text style={[styles.metaText, { color: colors.mutedForeground }]}>{room.branch}</Text></View><AvatarStack members={room.members} /></View>
      <View style={[styles.tabs, { borderBottomColor: colors.border }]}>{(['overview', 'files', 'terminal', 'chat'] as RoomTab[]).map((item) => <Pressable key={item} testID={`room-tab-${item}`} onPress={() => setTab(item)} style={({ pressed }) => [styles.tab, tab === item && { borderBottomColor: colors.primary, borderBottomWidth: 2 }, pressed && styles.pressed]}><Text style={[styles.tabText, { color: tab === item ? colors.primary : colors.mutedForeground }]}>{item.toUpperCase()}</Text></Pressable>)}</View>
      <ScrollView contentContainerStyle={{ padding: 18, paddingBottom: insets.bottom + 40 }} showsVerticalScrollIndicator={false}>
        {tab === 'overview' ? <Overview room={room} colors={colors} onAi={openAi} /> : null}
        {tab === 'files' ? <Files room={room} colors={colors} /> : null}
        {tab === 'terminal' ? <Terminal colors={colors} /> : null}
        {tab === 'chat' ? <ChatPreview colors={colors} onAi={openAi} /> : null}
      </ScrollView>
    </View>
  );
}

function Overview({ room, colors, onAi }: { room: NonNullable<ReturnType<typeof useApp>['rooms'][number]>; colors: ReturnType<typeof useColors>; onAi: () => void }) {
  return <><Surface style={styles.heroSurface}><View style={styles.heroTop}><View><Text style={[styles.heroEyebrow, { color: colors.mutedForeground }]}>ACTIVE DEBUG SESSION</Text><Text style={[styles.heroTitle, { color: colors.foreground }]}>Auth refresh guard</Text></View><View style={[styles.liveSquare, { backgroundColor: `${colors.accent}18` }]}><Feather name="radio" size={18} color={colors.accent} /></View></View><Text style={[styles.heroDetail, { color: colors.mutedForeground }]}>Pair-debugging a token rotation edge case. The AI is watching the current file for regressions.</Text><View style={styles.heroStats}><View><Text style={[styles.heroStatValue, { color: colors.foreground }]}>03</Text><Text style={[styles.heroStatLabel, { color: colors.mutedForeground }]}>COLLABORATORS</Text></View><View><Text style={[styles.heroStatValue, { color: colors.foreground }]}>18</Text><Text style={[styles.heroStatLabel, { color: colors.mutedForeground }]}>TESTS PASSING</Text></View><View><Text style={[styles.heroStatValue, { color: colors.accent }]}>{room.health}</Text><Text style={[styles.heroStatLabel, { color: colors.mutedForeground }]}>HEALTH</Text></View></View></Surface><View style={styles.actionRow}><Pressable testID="room-ask-ai" onPress={onAi} style={({ pressed }) => [styles.primaryAction, { backgroundColor: colors.primary }, pressed && styles.pressed]}><Feather name="message-square" size={16} color={colors.primaryForeground} /><Text style={[styles.primaryActionText, { color: colors.primaryForeground }]}>Ask AI about this room</Text></Pressable></View><Text style={[styles.subsectionLabel, { color: colors.mutedForeground }]}>CURRENT FILE</Text><Surface><View style={styles.fileTitleRow}><View style={[styles.fileIcon, { backgroundColor: `${colors.amber}18` }]}><Feather name="file-text" size={16} color={colors.amber} /></View><View style={styles.fileCopy}><Text style={[styles.fileTitle, { color: colors.foreground }]}>src/auth/refresh.ts</Text><Text style={[styles.fileDetail, { color: colors.mutedForeground }]}>TypeScript · modified by Jeevan 2m ago</Text></View><Feather name="chevron-right" size={17} color={colors.mutedForeground} /></View><MetricBar label="Bug risk" value={82} color={colors.destructive} /></Surface></>;
}

function Files({ room, colors }: { room: NonNullable<ReturnType<typeof useApp>['rooms'][number]>; colors: ReturnType<typeof useColors> }) {
  return <><Text style={[styles.subsectionLabel, { color: colors.mutedForeground }]}>FILE TREE · {room.files.length} FILES</Text><Surface>{room.files.map((file, index) => <View key={file} style={[styles.fileRow, index < room.files.length - 1 && { borderBottomColor: colors.border, borderBottomWidth: 1 }]}><Feather name={file.includes('.') ? 'file-text' : 'folder'} size={15} color={file.endsWith('.ts') ? colors.primary : colors.mutedForeground} /><Text style={[styles.filePath, { color: colors.foreground }]}>{file}</Text><Feather name="chevron-right" size={14} color={colors.mutedForeground} /></View>)}</Surface></>;
}

function Terminal({ colors }: { colors: ReturnType<typeof useColors> }) {
  return <><View style={[styles.terminalTop, { backgroundColor: colors.card, borderColor: colors.border }]}><View style={styles.terminalLabel}><View style={[styles.terminalDot, { backgroundColor: colors.accent }]} /><Text style={[styles.terminalTitle, { color: colors.foreground }]}>SHARED TERMINAL</Text></View><Text style={[styles.terminalStatus, { color: colors.accent }]}>CONNECTED</Text></View><View style={[styles.terminal, { backgroundColor: colors.terminal }]}><Text style={[styles.terminalLine, { color: colors.mutedForeground }]}>$ npm test -- auth/refresh</Text><Text style={[styles.terminalLine, { color: colors.accent }]}> PASS  tests/auth.spec.ts</Text><Text style={[styles.terminalLine, { color: colors.accent }]}>  ✓ rotates token after expiry</Text><Text style={[styles.terminalLine, { color: colors.accent }]}>  ✓ rejects stale refresh token</Text><Text style={[styles.terminalLine, { color: colors.accent }]}>  ✓ preserves session on retry</Text><Text style={[styles.terminalLine, { color: colors.mutedForeground }]}>{"\n"}Tests: 18 passed, 18 total</Text><Text style={[styles.terminalLine, { color: colors.primary }]}>{"\n"}$ _</Text></View></>;
}

function ChatPreview({ colors, onAi }: { colors: ReturnType<typeof useColors>; onAi: () => void }) {
  return <><Surface><View style={styles.aiHeader}><View style={[styles.aiIcon, { backgroundColor: `${colors.violet}18` }]}><Feather name="zap" size={16} color={colors.violet} /></View><View style={styles.aiCopy}><Text style={[styles.aiTitle, { color: colors.foreground }]}>AI Debug Companion</Text><Text style={[styles.aiDetail, { color: colors.mutedForeground }]}>Context-aware for this room</Text></View></View><Text style={[styles.aiMessage, { color: colors.foreground }]}>“The refresh guard can race when two requests expire together. I found a safe single-flight pattern in your test suite.”</Text><Pressable onPress={onAi} style={({ pressed }) => [styles.continueRow, pressed && styles.pressed]}><Text style={[styles.continueText, { color: colors.primary }]}>Continue the conversation</Text><Feather name="arrow-up-right" size={15} color={colors.primary} /></Pressable></Surface></>;
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  header: { paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center' },
  headerCopy: { flex: 1, marginLeft: 7 },
  headerEyebrow: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1.4, marginBottom: 4 },
  headerTitle: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  roomMeta: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 18, marginTop: 13, marginBottom: 20 },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 5, flex: 1 },
  metaText: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1, paddingHorizontal: 18 },
  tab: { paddingVertical: 12, marginRight: 21 },
  tabText: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.8 },
  heroSurface: { marginBottom: 13 },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  heroEyebrow: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 8 },
  heroTitle: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  liveSquare: { width: 36, height: 36, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  heroDetail: { fontSize: 11, lineHeight: 17, marginTop: 14, fontFamily: 'Inter_400Regular' },
  heroStats: { flexDirection: 'row', justifyContent: 'space-between', borderTopWidth: 1, borderTopColor: '#203651', marginTop: 17, paddingTop: 15 },
  heroStatValue: { fontSize: 18, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  heroStatLabel: { fontSize: 8, fontFamily: 'Inter_700Bold', letterSpacing: 0.8 },
  actionRow: { marginBottom: 24 },
  primaryAction: { height: 47, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  primaryActionText: { fontSize: 12, fontFamily: 'Inter_700Bold' },
  subsectionLabel: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 1.1, marginBottom: 10 },
  fileTitleRow: { flexDirection: 'row', alignItems: 'center' },
  fileIcon: { width: 34, height: 34, borderRadius: 10, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  fileCopy: { flex: 1 },
  fileTitle: { fontSize: 12, fontFamily: 'Inter_600SemiBold', marginBottom: 3 },
  fileDetail: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  fileRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 13, gap: 10 },
  filePath: { fontSize: 12, fontFamily: 'Inter_500Medium', flex: 1 },
  terminalTop: { padding: 13, borderWidth: 1, borderBottomWidth: 0, borderTopLeftRadius: 16, borderTopRightRadius: 16, flexDirection: 'row', justifyContent: 'space-between' },
  terminalLabel: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  terminalDot: { width: 7, height: 7, borderRadius: 4 },
  terminalTitle: { fontSize: 10, fontFamily: 'Inter_700Bold', letterSpacing: 0.8 },
  terminalStatus: { fontSize: 9, fontFamily: 'Inter_700Bold', letterSpacing: 0.7 },
  terminal: { padding: 16, minHeight: 240, borderBottomLeftRadius: 16, borderBottomRightRadius: 16 },
  terminalLine: { fontSize: 11, lineHeight: 20, fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace', default: 'monospace' }) },
  aiHeader: { flexDirection: 'row', alignItems: 'center' },
  aiIcon: { width: 35, height: 35, borderRadius: 11, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  aiCopy: { flex: 1 },
  aiTitle: { fontSize: 13, fontFamily: 'Inter_700Bold', marginBottom: 3 },
  aiDetail: { fontSize: 10, fontFamily: 'Inter_400Regular' },
  aiMessage: { fontSize: 12, lineHeight: 19, marginTop: 16, fontFamily: 'Inter_500Medium' },
  continueRow: { flexDirection: 'row', alignItems: 'center', gap: 7, marginTop: 17 },
  continueText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  pressed: { opacity: 0.65 },
});
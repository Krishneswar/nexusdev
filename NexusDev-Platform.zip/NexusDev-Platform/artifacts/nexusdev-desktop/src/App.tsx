import { useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  AlertTriangle,
  ArrowDownToLine,
  Bot,
  Braces,
  ChevronDown,
  ChevronRight,
  Command,
  FileJson,
  FileCode2,
  Folder,
  FolderOpen,
  GitBranch,
  GitCommitHorizontal,
  Hash,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Send,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  SquareTerminal,
  TerminalSquare,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type Room = { id: string; name: string; branch: string; count: number; color: string; live: boolean };
type FileItem = { name: string; kind: 'folder' | 'ts' | 'json' | 'md'; depth: number; open?: boolean };
type ChatMessage = { id: number; role: 'user' | 'assistant'; text: string; time: string };

const initialRooms: Room[] = [
  { id: 'checkout', name: 'Checkout timeout', branch: 'feat/payment-retry', count: 3, color: '#d5f84d', live: true },
  { id: 'sync', name: 'Realtime sync', branch: 'fix/socket-reconnect', count: 2, color: '#4ed7e8', live: true },
  { id: 'worker', name: 'Worker memory leak', branch: 'chore/queue-drain', count: 1, color: '#f1b95b', live: false },
];

const files: FileItem[] = [
  { name: 'src', kind: 'folder', depth: 0, open: true },
  { name: 'auth', kind: 'folder', depth: 1, open: true },
  { name: 'session.ts', kind: 'ts', depth: 2 },
  { name: 'middleware.ts', kind: 'ts', depth: 2 },
  { name: 'routes.ts', kind: 'ts', depth: 2 },
  { name: 'payments', kind: 'folder', depth: 1, open: false },
  { name: 'index.ts', kind: 'ts', depth: 1 },
  { name: 'package.json', kind: 'json', depth: 0 },
  { name: 'tsconfig.json', kind: 'json', depth: 0 },
  { name: 'README.md', kind: 'md', depth: 0 },
];

const codeByFile: Record<string, string[]> = {
  'session.ts': [
    "import { cookies } from 'next/headers';",
    "import { db } from '@/lib/db';",
    "import { sessions } from '@/lib/schema';",
    '',
    'const SESSION_TTL = 1000 * 60 * 60 * 24 * 30;',
    '',
    'export async function getSession() {',
    '  const token = cookies().get("session")?.value;',
    '',
    '  if (!token) return null;',
    '',
    '  const session = await db.query.sessions.findFirst({',
    '    where: (table, { eq }) => eq(table.token, token),',
    '    with: { user: true },',
    '  });',
    '',
    '  if (!session || session.expiresAt < new Date()) {',
    '    return null;',
    '  }',
    '',
    '  return session.user;',
    '}',
  ],
  'middleware.ts': [
    "import { getSession } from './session';",
    '',
    'export async function authMiddleware(request: Request) {',
    '  const session = await getSession();',
    '  if (!session) return new Response("Unauthorized", { status: 401 });',
    '  return null;',
    '}',
  ],
  'routes.ts': [
    "import { router } from '@/lib/router';",
    "import { authMiddleware } from './middleware';",
    '',
    'router.use(authMiddleware);',
    'router.get("/me", getCurrentUser);',
  ],
  'index.ts': ['export { getSession } from "./auth/session";', 'export { router } from "./router";'],
  'package.json': ['{', '  "name": "@nexusdev/checkout",', '  "private": true,', '  "scripts": {', '    "test": "vitest run"', '  }', '}'],
};

const codeTone = (line: string) => {
  if (line.startsWith('import')) return 'text-cyan-300';
  if (line.includes('export') || line.includes('async') || line.includes('return')) return 'text-violet-300';
  if (line.includes('//') || line.includes('const')) return 'text-amber-200';
  if (line.includes('"') || line.includes("'")) return 'text-emerald-300';
  return 'text-slate-300';
};

function Avatar({ initials, color, small = false }: { initials: string; color: string; small?: boolean }) {
  return (
    <span data-testid={`avatar-${initials}`} className={`inline-flex shrink-0 items-center justify-center rounded-full border border-[#344050] font-semibold ${small ? 'h-6 w-6 text-[9px]' : 'h-8 w-8 text-[10px]'}`} style={{ background: `${color}20`, color }}>
      {initials}
    </span>
  );
}

function FileIcon({ kind }: { kind: FileItem['kind'] }) {
  if (kind === 'folder') return <Folder size={14} />;
  if (kind === 'json') return <FileJson size={14} />;
  if (kind === 'md') return <Hash size={14} />;
  return <FileCode2 size={14} />;
}

function Home() {
  const [rooms, setRooms] = useState(initialRooms);
  const [roomId, setRoomId] = useState('checkout');
  const [selectedFile, setSelectedFile] = useState('session.ts');
  const [terminalOpen, setTerminalOpen] = useState(true);
  const [newRoomOpen, setNewRoomOpen] = useState(false);
  const [newRoomName, setNewRoomName] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [chat, setChat] = useState<ChatMessage[]>([
    { id: 1, role: 'assistant', text: 'I found one suspicious path in `getSession()`. The session lookup is doing a full user join before the expiry guard can short-circuit.', time: '10:42' },
    { id: 2, role: 'assistant', text: 'Want me to trace the request lifecycle from the checkout callback?', time: '10:42' },
  ]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({ src: true, auth: true });

  const activeRoom = rooms.find((room) => room.id === roomId) ?? rooms[0];
  const code = useMemo(() => codeByFile[selectedFile] ?? ['// Select a source file to inspect'], [selectedFile]);
  const visibleFiles = useMemo(() => files.filter((file) => {
    if (file.depth === 0) return true;
    if (file.name === 'session.ts' || file.name === 'middleware.ts' || file.name === 'routes.ts') return expanded.auth;
    return expanded.src;
  }), [expanded]);

  const sendChat = () => {
    const text = chatInput.trim();
    if (!text) return;
    const id = Date.now();
    setChat((current) => [...current, { id, role: 'user', text, time: 'now' }]);
    setChatInput('');
    window.setTimeout(() => {
      setChat((current) => [...current, { id: id + 1, role: 'assistant', text: 'I’m checking the active trace against that hypothesis. The fastest next move is to add a guard before the database join, then replay the timeout once.', time: 'now' }]);
    }, 420);
  };

  const createRoom = () => {
    const name = newRoomName.trim();
    if (!name) return;
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const room: Room = { id, name, branch: 'debug/' + id, count: 1, color: '#b89cff', live: true };
    setRooms((current) => [...current, room]);
    setRoomId(id);
    setNewRoomName('');
    setNewRoomOpen(false);
  };

  return (
    <div className="nd-app">
      <div className="nd-shell">
        <aside className="nd-sidebar flex min-h-0 flex-col">
          <div className="flex items-center justify-between border-b border-[#252d38] px-4 py-4">
            <div className="flex items-center gap-2.5">
              <div className="flex h-7 w-7 items-center justify-center rounded-[7px] bg-[#d5f84d] text-[#11161d]">
                <Braces size={16} strokeWidth={2.6} />
              </div>
              <div>
                <div className="text-[13px] font-bold tracking-tight text-[#ecf3f9]">nexus<span className="text-[#d5f84d]">dev</span></div>
                <div className="nd-label mt-0.5 text-[8px]">desktop / 01</div>
              </div>
            </div>
            <button data-testid="button-command-menu" className="nd-icon-button nd-focus-ring rounded-md p-1.5" title="Command menu"><Command size={15} /></button>
          </div>

          <div className="nd-scroll flex-1 px-3 py-4">
            <div className="mb-3 flex items-center justify-between px-2">
              <span className="nd-label">Live rooms</span>
              <button data-testid="button-new-room" onClick={() => setNewRoomOpen((value) => !value)} className="nd-icon-button nd-focus-ring rounded p-1" title="Start new room"><Plus size={15} /></button>
            </div>
            {newRoomOpen && (
              <div className="nd-fade-in mb-3 rounded-lg border border-[#3d4b35] bg-[#1b2824] p-2">
                <input data-testid="input-new-room" value={newRoomName} onChange={(event) => setNewRoomName(event.target.value)} onKeyDown={(event) => event.key === 'Enter' && createRoom()} autoFocus placeholder="Name your debug room" className="nd-focus-ring w-full rounded border border-[#42513b] bg-[#101920] px-2.5 py-2 text-xs text-[#e9f3de] placeholder:text-[#728178]" />
                <div className="mt-2 flex justify-end gap-1.5">
                  <button data-testid="button-cancel-room" onClick={() => setNewRoomOpen(false)} className="rounded px-2 py-1 text-[10px] text-[#8a988e] hover:text-[#e2ebe4]">Cancel</button>
                  <button data-testid="button-create-room" onClick={createRoom} className="rounded bg-[#d5f84d] px-2.5 py-1 text-[10px] font-bold text-[#11161d] hover:bg-[#e5ff6f]">Create room</button>
                </div>
              </div>
            )}
            <div className="space-y-1.5">
              {rooms.map((room) => (
                <button data-testid={`button-room-${room.id}`} key={room.id} onClick={() => setRoomId(room.id)} data-active={room.id === roomId} className="nd-room-row nd-focus-ring flex w-full items-start gap-2.5 rounded-lg border border-transparent px-2.5 py-2.5 text-left">
                  <span className={`mt-1 h-2 w-2 rounded-full ${room.live ? 'nd-pulse' : ''}`} style={{ background: room.color }} />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate text-[12px] font-semibold text-[#dce5ed]">{room.name}</span>
                      <span className="nd-mono text-[10px] text-[#738092]">{room.count}</span>
                    </span>
                    <span className="mt-1 block truncate font-mono text-[9px] text-[#778596]">{room.branch}</span>
                  </span>
                </button>
              ))}
            </div>

            <div className="mt-8">
              <div className="mb-3 flex items-center justify-between px-2">
                <span className="nd-label">Repository</span>
                <button data-testid="button-refresh-repo" className="nd-icon-button nd-focus-ring rounded p-1" title="Refresh repository"><RefreshCw size={13} /></button>
              </div>
              <div className="space-y-0.5">
                {visibleFiles.map((file) => {
                  const isFolder = file.kind === 'folder';
                  const isSelected = file.name === selectedFile;
                  return (
                    <button data-testid={`button-file-${file.name}`} key={`${file.depth}-${file.name}`} onClick={() => isFolder ? setExpanded((current) => ({ ...current, [file.name]: !current[file.name] })) : setSelectedFile(file.name)} data-selected={isSelected} className="nd-file-row nd-focus-ring flex w-full items-center gap-2 rounded-md py-1.5 pr-2 text-left text-[11px]" style={{ paddingLeft: `${10 + file.depth * 13}px` }}>
                      {isFolder ? (expanded[file.name] ? <ChevronDown size={13} className="text-[#8492a2]" /> : <ChevronRight size={13} className="text-[#8492a2]" />) : <span className="w-[13px]" />}
                      <span className={isFolder ? 'text-[#b7c4d0]' : 'text-[#8291a1]'}>{isFolder && expanded[file.name] ? <FolderOpen size={14} /> : <FileIcon kind={file.kind} />}</span>
                      <span className="truncate">{file.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="border-t border-[#252d38] p-3">
            <button data-testid="button-user-profile" className="nd-focus-ring flex w-full items-center gap-2.5 rounded-lg p-2 text-left hover:bg-[#1c2530]">
              <Avatar initials="AK" color="#d5f84d" small />
              <span className="min-w-0 flex-1"><span className="block text-[11px] font-semibold text-[#dce5ed]">Alex Kim</span><span className="block text-[9px] text-[#7e8b9b]">Principal engineer</span></span>
              <Settings2 size={14} className="text-[#788697]" />
            </button>
          </div>
        </aside>

        <main className="nd-main nd-grid-texture">
          <header className="flex h-[62px] shrink-0 items-center justify-between border-b border-[#252d38] bg-[#121821]/90 px-5 backdrop-blur-md">
            <div className="flex min-w-0 items-center gap-3">
              <div className="flex items-center gap-2 text-[11px] text-[#8290a0]"><span>Rooms</span><ChevronRight size={13} /><span className="truncate font-semibold text-[#dfe8ef]">{activeRoom.name}</span></div>
              <span className="hidden h-4 w-px bg-[#303945] sm:block" />
              <div className="hidden items-center gap-1.5 rounded-md border border-[#2c3744] bg-[#1a222d] px-2 py-1.5 sm:flex"><GitBranch size={13} className="text-[#d5f84d]" /><span className="nd-mono text-[10px] text-[#a5b2bf]">{activeRoom.branch}</span><ChevronDown size={12} className="text-[#748295]" /></div>
            </div>
            <div className="flex items-center gap-2.5">
              <div className="hidden items-center gap-2 text-[10px] text-[#94a2ae] md:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#d5f84d] shadow-[0_0_0_3px_rgba(213,248,77,0.12)]" />session synced <span className="nd-mono text-[#677687]">2.8s</span></div>
              <button data-testid="button-terminal-toggle" onClick={() => setTerminalOpen((value) => !value)} className={`nd-focus-ring flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-[10px] font-semibold transition-colors ${terminalOpen ? 'border-[#4a5934] bg-[#273321] text-[#d5f84d]' : 'border-[#303a46] text-[#9aa7b6] hover:bg-[#202a35]'}`}><TerminalSquare size={14} /> Terminal</button>
              <button data-testid="button-more-actions" className="nd-icon-button nd-focus-ring rounded-md p-1.5"><MoreHorizontal size={17} /></button>
            </div>
          </header>

          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex h-10 shrink-0 items-center border-b border-[#252d38] bg-[#141b24] px-4">
              <div className="flex h-full items-center gap-2 border-r border-[#2a333f] pr-4 text-[11px] text-[#d9e4ed]"><FileCode2 size={14} className="text-[#d5f84d]" />{selectedFile}<button data-testid="button-close-file" onClick={() => setSelectedFile('session.ts')} className="ml-2 text-[#667587] hover:text-[#d9e4ed]"><X size={12} /></button></div>
              <div className="ml-auto flex items-center gap-3"><span className="nd-label hidden sm:block">working tree clean</span><GitCommitHorizontal size={14} className="text-[#8290a0]" /><span className="nd-mono text-[10px] text-[#768494]">a81f6d2</span></div>
            </div>

            <div className={`nd-code-area nd-scroll min-h-0 flex-1 overflow-auto bg-[#111720]/90 ${terminalOpen ? 'basis-[56%]' : 'basis-full'}`}>
              <div className="min-w-[580px] py-4 font-mono text-[11px] leading-[1.85]">
                {code.map((line, index) => (
                  <div data-testid={`code-line-${index + 1}`} data-active={index === 14} key={`${selectedFile}-${index}`} className="nd-code-line flex min-h-[21px]">
                    <span className="w-12 shrink-0 select-none pr-4 text-right text-[#4e5b6b]">{index + 1}</span>
                    <span className={`whitespace-pre ${codeTone(line)}`}>{line || ' '}</span>
                    {index === 14 && <span className="ml-5 rounded border border-[#754744] bg-[#3a282a] px-1.5 text-[9px] leading-4 text-[#ef9b8e]">possible stale session</span>}
                  </div>
                ))}
              </div>
            </div>

            {terminalOpen && (
              <section className="flex min-h-[220px] basis-[44%] flex-col border-t border-[#303945] bg-[#0e141b]">
                <div className="flex h-9 shrink-0 items-center justify-between border-b border-[#252d38] px-4">
                  <div className="flex items-center gap-2"><SquareTerminal size={14} className="text-[#4ed7e8]" /><span className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#aab6c2]">Live terminal</span><span className="rounded bg-[#20352f] px-1.5 py-0.5 text-[9px] text-[#77dcad]">connected</span></div>
                  <div className="flex items-center gap-1"><button data-testid="button-clear-terminal" className="nd-icon-button nd-focus-ring rounded p-1.5" title="Clear terminal"><X size={13} /></button><button data-testid="button-terminal-download" className="nd-icon-button nd-focus-ring rounded p-1.5" title="Download output"><ArrowDownToLine size={13} /></button></div>
                </div>
                <div className="nd-scroll flex-1 p-4 font-mono text-[10px] leading-[1.9]">
                  <div className="nd-terminal-line text-[#718092]">09:41:08 <span className="text-[#4ed7e8]">room</span> attached to process <span className="text-[#d8e4ee]">checkout-web.1</span></div>
                  <div className="nd-terminal-line text-[#718092]" style={{ animationDelay: '70ms' }}>09:41:12 <span className="text-[#d5f84d]">GET</span> /api/checkout/session <span className="text-[#edc46f]">504</span> 30.01s</div>
                  <div className="nd-terminal-line text-[#718092]" style={{ animationDelay: '140ms' }}>09:41:12 <span className="text-[#e57d70]">warn</span> upstream request exceeded timeout <span className="text-[#d8e4ee]">trace=8a1f…</span></div>
                  <div className="nd-terminal-line text-[#718092]" style={{ animationDelay: '210ms' }}>09:41:13 <span className="text-[#4ed7e8]">POST</span> /api/checkout/retry <span className="text-[#77dcad]">202</span> 412ms</div>
                  <div className="nd-terminal-line mt-1 text-[#788697]"><span className="text-[#d5f84d]">›</span> replay --trace 8a1f --verbose<span className="ml-1 inline-block h-3 w-1.5 animate-pulse bg-[#d5f84d] align-middle" /></div>
                </div>
              </section>
            )}
          </div>
        </main>

        <aside className="nd-inspector flex min-h-0 flex-col">
          <div className="flex h-[62px] shrink-0 items-center justify-between border-b border-[#252d38] px-4">
            <div><div className="text-[12px] font-semibold text-[#e0e8ef]">Room telemetry</div><div className="mt-0.5 text-[10px] text-[#758394]">observability / live context</div></div>
            <button data-testid="button-inspector-settings" className="nd-icon-button nd-focus-ring rounded p-1.5"><SlidersHorizontal size={15} /></button>
          </div>
          <div className="nd-scroll flex min-h-0 flex-1 flex-col">
            <section className="border-b border-[#252d38] p-4">
              <div className="mb-3 flex items-center justify-between"><span className="nd-label">Collaborators · {activeRoom.count}</span><button data-testid="button-invite-collaborator" className="nd-icon-button nd-focus-ring rounded p-1" title="Invite collaborator"><Plus size={14} /></button></div>
              <div className="space-y-2">
                {[['AK', 'Alex Kim', 'editing session.ts', '#d5f84d'], ['MR', 'Maya Rao', 'watching trace', '#4ed7e8'], ['JL', 'Jon Lee', 'in terminal', '#b89cff']].slice(0, activeRoom.count + 1).map(([initials, name, state, color]) => (
                  <div data-testid={`presence-${initials}`} key={initials} className="flex items-center gap-2.5"><Avatar initials={initials} color={color} small /><div className="min-w-0 flex-1"><div className="text-[11px] font-semibold text-[#cfd9e2]">{name}</div><div className="truncate text-[9px] text-[#748293]">{state}</div></div><span className="h-1.5 w-1.5 rounded-full bg-[#7fd994]" /></div>
                ))}
              </div>
            </section>

            <section className="border-b border-[#252d38] p-4">
              <div className="mb-3 flex items-center justify-between"><span className="nd-label">Code health</span><span className="flex items-center gap-1 text-[10px] text-[#d5f84d]"><ShieldCheck size={13} /> 86 / good</span></div>
              <div className="space-y-3">
                <div><div className="mb-1.5 flex justify-between text-[10px]"><span className="text-[#9aa7b5]">Request latency</span><span className="nd-mono text-[#e2c773]">412ms</span></div><div className="nd-signal"><span style={{ width: '68%', background: '#e2c773' }} /></div></div>
                <div><div className="mb-1.5 flex justify-between text-[10px]"><span className="text-[#9aa7b5]">Error rate</span><span className="nd-mono text-[#ef9286]">2.4%</span></div><div className="nd-signal"><span style={{ width: '34%', background: '#ef9286' }} /></div></div>
                <div><div className="mb-1.5 flex justify-between text-[10px]"><span className="text-[#9aa7b5]">Test coverage</span><span className="nd-mono text-[#91d98b]">78.6%</span></div><div className="nd-signal"><span style={{ width: '79%', background: '#91d98b' }} /></div></div>
              </div>
              <div className="mt-4 flex items-start gap-2 rounded-md border border-[#574639] bg-[#2b2520] p-2.5"><AlertTriangle size={14} className="mt-0.5 shrink-0 text-[#efb96c]" /><div><div className="text-[10px] font-semibold text-[#f2cd91]">1 risk needs attention</div><div className="mt-1 text-[9px] leading-4 text-[#ae967b]">Session expiry is checked after the user join.</div></div></div>
            </section>

            <section className="flex min-h-[360px] flex-1 flex-col p-4">
              <div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2"><Bot size={15} className="text-[#d5f84d]" /><span className="nd-label">Debug companion</span></div><span className="flex items-center gap-1 text-[9px] text-[#7fc996]"><span className="h-1.5 w-1.5 rounded-full bg-[#7fc996]" />ready</span></div>
              <div className="nd-chat-scroll flex-1 space-y-3 pr-1">
                {chat.map((message) => (
                  <div data-testid={`chat-message-${message.id}`} key={message.id} className={`nd-rise flex gap-2 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}>
                    {message.role === 'assistant' ? <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md border border-[#465535] bg-[#29351f] text-[#d5f84d]"><Sparkles size={12} /></div> : <Avatar initials="AK" color="#d5f84d" small />}
                    <div className={`max-w-[86%] rounded-lg px-2.5 py-2 text-[10px] leading-[1.55] ${message.role === 'assistant' ? 'border border-[#2b3640] bg-[#1a222c] text-[#b8c4cf]' : 'bg-[#344120] text-[#e4f2bd]'}`}><div>{message.text}</div><div className="mt-1 text-[8px] text-[#708091]">{message.time}</div></div>
                  </div>
                ))}
              </div>
              <div className="mt-3 rounded-lg border border-[#303b47] bg-[#161e27] p-2 focus-within:border-[#667f39]">
                <textarea data-testid="input-ai-message" value={chatInput} onChange={(event) => setChatInput(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendChat(); } }} placeholder="Ask about this trace or file…" rows={2} className="nd-focus-ring w-full resize-none bg-transparent text-[10px] leading-4 text-[#dbe5ed] outline-none placeholder:text-[#6f7d8d]" />
                <div className="mt-1 flex items-center justify-between"><span className="text-[9px] text-[#6e7c8b]">Return to send · Shift + Return for line break</span><button data-testid="button-send-ai" onClick={sendChat} className="nd-focus-ring flex h-6 w-6 items-center justify-center rounded-md bg-[#d5f84d] text-[#12171d] transition-transform hover:scale-105"><Send size={12} /></button></div>
              </div>
            </section>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
